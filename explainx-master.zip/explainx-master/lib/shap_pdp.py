from imports import *


class shap_pdp():
    def __init__(self):
        super(shap_pdp, self).__init__()
        self.param= None

    def find(self,  df):

        return df


